#!/usr/bin/env python3
"""ATLAS FLOW (Termux edition) - real packet/flow/network analysis. Stdlib only. Passive by design.
Sources: PCAP / PCAPNG files, a PCAPdroid TCP stream (no root), or live AF_PACKET capture (root / CAP_NET_RAW).
Nothing is simulated: every number shown is derived from packets actually read."""
import struct, socket, time, threading, json, os, sys, re, ipaddress, math, statistics, argparse, mmap, stat, tempfile, shutil, subprocess, mimetypes
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from collections import defaultdict, Counter

HERE = os.path.dirname(os.path.abspath(__file__))
TERMUX = 'com.termux' in os.environ.get('PREFIX', '') or os.path.isdir('/data/data/com.termux')
MAXP = int(os.environ.get('ATLASFLOW_MAXP', 300_000 if TERMUX else 1_500_000))   # phones: keep RAM sane
PCAPDROID_PORT = 5123
PORTS = {53:'DNS',5353:'mDNS',80:'HTTP',8080:'HTTP',443:'TLS',853:'TLS',22:'SSH',23:'TELNET',21:'FTP',25:'SMTP',110:'POP3',143:'IMAP',
         123:'NTP',67:'DHCP',68:'DHCP',1900:'SSDP',445:'SMB',3389:'RDP',161:'SNMP',389:'LDAP',3306:'MYSQL',5432:'PGSQL',6379:'REDIS'}
CLEARTEXT = {21:'FTP',23:'TELNET',25:'SMTP',80:'HTTP',110:'POP3',143:'IMAP',161:'SNMP',389:'LDAP'}

def mac(b): return ':'.join('%02x' % x for x in b)
def tcpf(f): return ','.join(n for m, n in [(2,'SYN'),(1,'FIN'),(4,'RST'),(8,'PSH'),(16,'ACK'),(32,'URG')] if f & m)

# ---------------------------------------------------------------- file readers
def read_capture(path, cb, prog=None):
    with open(path, 'rb') as f:
        if os.fstat(f.fileno()).st_size < 24: raise ValueError('file too small to be a capture')
        data = mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ)   # no full copy in RAM
    try: return _read(data, cb, prog)
    finally: data.close()

def _read(data, cb, prog):
    m = data[:4]
    if m == b'\x0a\x0d\x0d\x0a': return _pcapng(data, cb, prog)
    if m not in _MAGICS: raise ValueError('not a PCAP or PCAPNG file (bad magic)')
    e, res = _MAGICS[m]
    lt = struct.unpack(e + 'I', data[20:24])[0] & 0xffff
    o, n, i = 24, len(data), 0
    while o + 16 <= n:
        s, us, cl, ol = struct.unpack(e + 'IIII', data[o:o+16]); o += 16
        if cl > 262144 or o + cl > n: break
        cb(s + us * res, lt, data[o:o+cl]); o += cl; i += 1
        if prog and not i & 1023: prog(o, n)
    return 'pcap'

def _ng_block(e, bt, body, ifs, cb):
    if bt == 1 and len(body) >= 8:
        lt = struct.unpack(e + 'H', body[:2])[0]; res = 1e-6; p = 8
        while p + 4 <= len(body):
            oc, ol = struct.unpack(e + 'HH', body[p:p+4])
            if oc == 0: break
            if oc == 9 and ol >= 1:
                v = body[p+4]; res = 2.0 ** -(v & 0x7f) if v & 0x80 else 10.0 ** -v
            p += 4 + (ol + 3) // 4 * 4
        ifs.append((lt, res))
    elif bt == 6 and len(body) >= 20:
        i, hi, lo, cl, ol = struct.unpack(e + 'IIIII', body[:20])
        lt, res = ifs[i] if i < len(ifs) else (1, 1e-6)
        cb(((hi << 32) | lo) * res, lt, body[20:20+cl])
    elif bt == 3 and len(body) >= 4 and ifs:
        cb(0.0, ifs[0][0], body[4:])

def _pcapng(data, cb, prog):
    e, o, n, ifs, i = '<', 0, len(data), [], 0
    while o + 12 <= n:
        if data[o:o+4] == b'\x0a\x0d\x0d\x0a':
            e = '<' if data[o+8:o+12] == b'\x4d\x3c\x2b\x1a' else '>'; ifs = []
        bt, bl = struct.unpack(e + 'II', data[o:o+8])
        if bl < 12 or o + bl > n: break
        _ng_block(e, bt, data[o+8:o+bl-4], ifs, cb)
        o += bl; i += 1
        if prog and not i & 1023: prog(o, n)
    return 'pcapng'

_MAGICS = {b'\xd4\xc3\xb2\xa1':('<',1e-6), b'\xa1\xb2\xc3\xd4':('>',1e-6), b'\x4d\x3c\xb2\xa1':('<',1e-9), b'\xa1\xb2\x3c\x4d':('>',1e-9)}

class StreamParser:
    """Incremental PCAP/PCAPNG parser for live byte streams (PCAPdroid TCP exporter)."""
    def __init__(s, cb): s.cb, s.buf, s.kind, s.e, s.res, s.lt, s.ifs = cb, bytearray(), None, '<', 1e-6, 1, []
    def feed(s, data):
        b = s.buf; b += data; o = 0
        if s.kind is None:
            if len(b) < 24: return
            m = bytes(b[:4])
            if m == b'\x0a\x0d\x0d\x0a': s.kind = 'ng'
            elif m in _MAGICS: s.kind = 'pcap'; s.e, s.res = _MAGICS[m]; s.lt = struct.unpack(s.e + 'I', bytes(b[20:24]))[0] & 0xffff; o = 24
            else: raise ValueError('stream is not PCAP/PCAPNG')
        if s.kind == 'pcap':
            while len(b) - o >= 16:
                sec, us, cl, ol = struct.unpack(s.e + 'IIII', bytes(b[o:o+16]))
                if cl > 262144: raise ValueError('corrupt pcap record')
                if len(b) - o - 16 < cl: break
                s.cb(sec + us * s.res, s.lt, bytes(b[o+16:o+16+cl])); o += 16 + cl
        else:
            while len(b) - o >= 12:
                if bytes(b[o:o+4]) == b'\x0a\x0d\x0d\x0a':
                    s.e = '<' if bytes(b[o+8:o+12]) == b'\x4d\x3c\x2b\x1a' else '>'; s.ifs = []
                bt, bl = struct.unpack(s.e + 'II', bytes(b[o:o+8]))
                if bl < 12 or bl > (1 << 22): raise ValueError('corrupt pcapng block')
                if len(b) - o < bl: break
                _ng_block(s.e, bt, bytes(b[o+8:o+bl-4]), s.ifs, s.cb); o += bl
        del b[:o]

# ---------------------------------------------------------------- dissectors
def dname(b, o):
    parts, end, hops = [], None, 0
    while o < len(b) and hops < 20:
        l = b[o]
        if l == 0: o += 1; break
        if l & 0xC0 == 0xC0:
            if o + 1 >= len(b): break
            if end is None: end = o + 2
            o = ((l & 0x3F) << 8) | b[o+1]; hops += 1; continue
        parts.append(b[o+1:o+1+l].decode('ascii', 'replace')); o += 1 + l
    return '.'.join(parts), (end if end is not None else o)

def dns(b):
    if len(b) < 12: return None
    _, f, qd, an = struct.unpack('>HHHH', b[:8]); o, q = 12, None
    if qd: q, o = dname(b, o); o += 4
    ans = []
    for _ in range(min(an, 24)):
        _, o = dname(b, o)
        if o + 10 > len(b): break
        t, _, _, rl = struct.unpack('>HHIH', b[o:o+10]); o += 10; r = b[o:o+rl]
        if t == 1 and rl == 4: ans.append(socket.inet_ntoa(r))
        elif t == 28 and rl == 16: ans.append(socket.inet_ntop(socket.AF_INET6, r))
        o += rl
    return dict(q=q, qr=f >> 15, rc=f & 15, ans=ans)

def sni(p):
    try:
        if len(p) < 43 or p[0] != 0x16 or p[5] != 1: return None
        o = 43; o += 1 + p[o]; o += 2 + struct.unpack('>H', p[o:o+2])[0]; o += 1 + p[o]
        end = o + 2 + struct.unpack('>H', p[o:o+2])[0]; o += 2
        while o + 4 <= end:
            t, l = struct.unpack('>HH', p[o:o+4]); o += 4
            if t == 0:
                nl = struct.unpack('>H', p[o+3:o+5])[0]; return p[o+5:o+5+nl].decode('ascii', 'replace')
            o += l
    except Exception: pass

HM = (b'GET ', b'POST ', b'PUT ', b'HEAD ', b'DELETE ', b'OPTIONS ', b'PATCH ')
def http(p):
    if p.startswith(HM):
        i = p.find(b'\r\n'); line = p[:i if i > 0 else 120][:120].decode('latin1')
        h = re.search(rb'\r\nHost: ([^\r\n]+)', p[:2048], re.I)
        return dict(line=line, host=h.group(1).decode('latin1') if h else None)

def L(d, name, **kv):
    if d.get('det'): d['layers'].append((name, [(k, str(v)) for k, v in kv.items()]))

def l4(proto, b, d):
    if proto == 6 and len(b) >= 20:
        sp, dp, seq, ack, off, f, win = struct.unpack('>HHIIBBH', b[:16]); hl = max(20, (off >> 4) * 4); pl = b[hl:]
        d.update(tp='TCP', sp=sp, dp=dp, flags=f, plen=len(pl), info=f'{sp} → {dp} [{tcpf(f)}] Seq={seq} Ack={ack} Win={win} Len={len(pl)}')
        L(d, 'TCP', src_port=sp, dst_port=dp, seq=seq, ack=ack, flags=tcpf(f), window=win, payload_len=len(pl))
        h = http(pl) if pl else None; s = sni(pl) if pl else None
        if s: d['sni'] = s; d['app'] = 'TLS'; d['info'] += f' SNI={s}'
        elif h: d['http'] = h; d['app'] = 'HTTP'; d['info'] += f' {h["line"]}'
        elif pl[:1] == b'\x16' and pl[1:2] == b'\x03': d['app'] = 'TLS'
        else: d['app'] = PORTS.get(min(sp, dp)) if min(sp, dp) in PORTS else None
        if pl and 'app' in d and d['app'] is None: del d['app']
    elif proto == 17 and len(b) >= 8:
        sp, dp, ln = struct.unpack('>HHH', b[:6]); pl = b[8:]
        d.update(tp='UDP', sp=sp, dp=dp, plen=len(pl), info=f'{sp} → {dp} Len={len(pl)}'); L(d, 'UDP', src_port=sp, dst_port=dp, length=ln)
        if 53 in (sp, dp) or 5353 in (sp, dp):
            q = dns(pl)
            if q:
                d['dns'] = q; d['app'] = 'DNS' if 53 in (sp, dp) else 'mDNS'
                d['info'] = ('Response ' if q['qr'] else 'Query ') + f'{q["q"]} ' + (f'rcode={q["rc"]} ' if q['rc'] else '') + ' '.join(q['ans'])
                L(d, 'DNS', query=q['q'], response=q['qr'], rcode=q['rc'], answers=','.join(q['ans']))
        else: d['app'] = PORTS.get(min(sp, dp))
        if d.get('app') is None: d.pop('app', None)
    elif proto in (1, 58) and len(b) >= 2:
        d.update(tp='ICMP' if proto == 1 else 'ICMPv6', sp=0, dp=0, info=f'type={b[0]} code={b[1]}'); L(d, d['tp'], type=b[0], code=b[1])
    else:
        d.update(tp=f'IP/{proto}', sp=0, dp=0, info=f'IP protocol {proto}')

def l3(et, b, d):
    if et == 0x0806 and len(b) >= 28:
        op = struct.unpack('>H', b[6:8])[0]; sha, spa, tpa = mac(b[8:14]), socket.inet_ntoa(b[14:18]), socket.inet_ntoa(b[24:28])
        d.update(tp='ARP', src=spa, dst=tpa, sp=0, dp=0, smac=sha, info=f'Who has {tpa}? Tell {spa}' if op == 1 else f'{spa} is at {sha}')
        L(d, 'ARP', op=op, sender_mac=sha, sender_ip=spa, target_ip=tpa)
    elif et == 0x0800 and len(b) >= 20:
        ihl = (b[0] & 15) * 4; tot = struct.unpack('>H', b[2:4])[0]; ttl, pr = b[8], b[9]; frag = struct.unpack('>H', b[6:8])[0] & 0x1fff
        d['src'], d['dst'], d['ip'] = socket.inet_ntoa(b[12:16]), socket.inet_ntoa(b[16:20]), 4
        L(d, 'IPv4', src=d['src'], dst=d['dst'], ttl=ttl, protocol=pr, total_len=tot)
        if frag: d.update(tp='IP/frag', sp=0, dp=0, info='Fragment')
        else: l4(pr, b[ihl:tot if 0 < tot <= len(b) else len(b)], d)
    elif et == 0x86dd and len(b) >= 40:
        nh, o = b[6], 40; d['src'], d['dst'], d['ip'] = socket.inet_ntop(socket.AF_INET6, b[8:24]), socket.inet_ntop(socket.AF_INET6, b[24:40]), 6
        L(d, 'IPv6', src=d['src'], dst=d['dst'], next_header=nh, hop_limit=b[7])
        while nh in (0, 43, 60, 44) and o + 8 <= len(b):
            n2 = b[o]; o += 8 if nh == 44 else (b[o+1] + 1) * 8; nh = n2
        l4(nh, b[o:], d)
    else: d.update(tp=f'ETH/0x{et:04x}', info=f'EtherType 0x{et:04x}')

IE_NAMES = {0: 'SSID', 3: 'DS', 48: 'RSN'}
def ies(b):
    o, r = 0, {}
    while o + 2 <= len(b):
        i, l = b[o], b[o+1]; v = b[o+2:o+2+l]
        if i == 221 and v[:4] == b'\x00\x50\xf2\x01': r['wpa'] = v
        elif i not in r: r[i] = v
        o += 2 + l
    return r

def enc_of(r, cap):
    if 48 in r:
        v = r[48]
        try:
            o = 2 + 4; pc = struct.unpack('<H', v[o:o+2])[0]; o += 2 + 4 * pc
            ac = struct.unpack('<H', v[o:o+2])[0]; o += 2; ak = {v[o+4*i+3] for i in range(ac)}
            if 8 in ak and 2 in ak: return 'WPA2/WPA3'
            if 8 in ak: return 'WPA3'
            if 1 in ak and 2 not in ak: return 'WPA2-ENT'
        except Exception: pass
        return 'WPA2'
    if 'wpa' in r: return 'WPA'
    return 'WEP' if cap & 0x10 else 'OPEN'

def chan(f): return 14 if f == 2484 else (f - 2407) // 5 if f < 3000 else (f - 5950) // 5 if f > 5900 and f >= 5955 else (f - 5000) // 5

def radiotap(b):
    if len(b) < 8: return None
    ln = struct.unpack('<H', b[2:4])[0]; pr = struct.unpack('<I', b[4:8])[0]; o, p, info = 8, pr, {}
    while p & 0x80000000 and o + 4 <= ln: p = struct.unpack('<I', b[o:o+4])[0]; o += 4
    al = lambda n: (o + n - 1) // n * n
    try:
        if pr & 1: o = al(8) + 8
        if pr & 2: o += 1
        if pr & 4: o += 1
        if pr & 8: o = al(2); info['freq'] = struct.unpack('<H', b[o:o+2])[0]; o += 4
        if pr & 16: o += 2
        if pr & 32: info['rssi'] = struct.unpack('<b', b[o:o+1])[0]
    except Exception: pass
    return ln, info

MG = {0:'AssocReq',1:'AssocResp',2:'ReassocReq',3:'ReassocResp',4:'ProbeReq',5:'ProbeResp',8:'Beacon',10:'Disassoc',11:'Auth',12:'Deauth',13:'Action'}
def wlan(b, d, rt):
    if len(b) < 10: d.update(tp='WLAN', info='short 802.11 frame'); return
    fc0, fc1 = b[0], b[1]; t, st = (fc0 >> 2) & 3, fc0 >> 4
    a1 = mac(b[4:10]); a2 = mac(b[10:16]) if len(b) >= 16 else ''; a3 = mac(b[16:22]) if len(b) >= 22 else ''
    w = dict(t=t, st=st, a1=a1, a2=a2, a3=a3, rssi=rt.get('rssi'), ch=chan(rt['freq']) if 'freq' in rt else None)
    d.update(tp='WLAN', src=a2 or a1, dst=a1, sp=0, dp=0, wlan=w)
    if t == 0:
        nm = MG.get(st, f'Mgmt{st}'); w['name'] = nm; w['bssid'] = a3; d['info'] = f'{nm} {a2} → {a1}'
        body = b[24:]
        if st in (8, 5) and len(body) >= 12:
            cap = struct.unpack('<H', body[10:12])[0]; r = ies(body[12:]); w['ssid'] = r.get(0, b'').decode('utf8', 'replace'); w['enc'] = enc_of(r, cap)
            if 3 in r and r[3]: w['ch'] = r[3][0]
            d['info'] += f' SSID="{w["ssid"]}" ch={w["ch"]} {w["enc"]}'
        elif st == 4: r = ies(body); w['ssid'] = r.get(0, b'').decode('utf8', 'replace'); d['info'] += f' SSID="{w["ssid"]}"' if w['ssid'] else ' (wildcard)'
        elif st in (10, 12) and len(body) >= 2: w['reason'] = struct.unpack('<H', body[:2])[0]; d['info'] += f' reason={w["reason"]}'
        L(d, '802.11 Management', subtype=nm, receiver=a1, transmitter=a2, bssid=a3, ssid=w.get('ssid', ''), channel=w['ch'], rssi=w['rssi'])
    elif t == 2:
        ds = fc1 & 3; w['name'] = 'Data'
        w['bssid'], w['sta'] = (a3, a2) if ds == 0 else (a1, a2) if ds == 1 else (a2, a1) if ds == 2 else (None, None)
        if ds == 0: w['sta'] = None
        hl = 24 + (6 if ds == 3 else 0) + (2 if st & 8 else 0); d['info'] = f'Data {a2} → {a1}' + (' [protected]' if fc1 & 0x40 else '')
        L(d, '802.11 Data', transmitter=a2, receiver=a1, bssid=w['bssid'], protected=bool(fc1 & 0x40), rssi=w['rssi'])
        if not fc1 & 0x40 and st & 0x0c == 0 and len(b) >= hl + 8 and b[hl:hl+3] == b'\xaa\xaa\x03':
            et = struct.unpack('>H', b[hl+6:hl+8])[0]; pl = b[hl+8:]
            if et == 0x888e and len(pl) >= 99:
                ki = struct.unpack('>H', pl[5:7])[0]; A, M, I, S = ki & 0x80, ki & 0x100, ki & 0x40, ki & 0x200
                msg = 3 if (A and M and I) else 1 if (A and not M) else 4 if (M and S and not A) else 2 if (M and not A) else 0
                w['eapol'] = msg; d['info'] = f'EAPOL-Key message {msg}/4 {a2} → {a1}'; d['app'] = 'EAPOL'
            elif et in (0x0800, 0x86dd, 0x0806):
                keep = dict(wlan=w); l3(et, pl, d); d.update(keep)
    else: d['info'] = f'802.11 {"Control" if t == 1 else "Ext"} st={st}'; w['name'] = 'Ctrl'

def dissect(raw, lt, det=False):
    d = dict(tp='?', src='', dst='', sp=0, dp=0, info='', det=det, layers=[])
    try:
        if lt in (1, 113):
            if lt == 1 and len(raw) >= 14:
                et, o = struct.unpack('>H', raw[12:14])[0], 14; d['smac'] = mac(raw[6:12]); L(d, 'Ethernet', dst=mac(raw[0:6]), src=mac(raw[6:12]), type=f'0x{et:04x}')
                while et in (0x8100, 0x88a8) and len(raw) >= o + 4: et = struct.unpack('>H', raw[o+2:o+4])[0]; o += 4
            elif lt == 113 and len(raw) >= 16: et, o = struct.unpack('>H', raw[14:16])[0], 16
            else: raise ValueError('short')
            l3(et, raw[o:], d)
        elif lt in (101, 12, 228, 229): l3(0x0800 if raw[:1] and raw[0] >> 4 == 4 else 0x86dd, raw, d)
        elif lt == 127:
            r = radiotap(raw)
            if r: wlan(raw[r[0]:], d, r[1])
        elif lt == 105: wlan(raw, d, {})
        else: d.update(tp=f'LT{lt}', info=f'Unsupported link type {lt}')
    except Exception as ex: d.update(tp=d.get('tp', '?'), info=(d.get('info') or '') + f' [decode error: {ex}]')
    d['label'] = d.get('app') or d['tp']
    return d

# ---------------------------------------------------------------- store
def is_priv(ip):
    try: a = ipaddress.ip_address(ip); return a.is_private or a.is_link_local
    except ValueError: return False
def is_multi(ip):
    try: a = ipaddress.ip_address(ip); return a.is_multicast or ip.endswith('.255') or ip == '255.255.255.255'
    except ValueError: return ip.lower().startswith('ff:')

class Store:
    def __init__(s): s.lock = threading.RLock(); s.reset()
    def reset(s):
        with s.lock:
            s.raw, s.pk, s.flows, s.fl, s.hosts, s.names = [], [], {}, [], {}, {}
            s.aps, s.sta, s.hs, s.deauth, s.nx = {}, {}, {}, {}, Counter()
            s.tl = defaultdict(lambda: [0, 0]); s.rev = 0; s.dropped = 0; s.src = None; s.err = None; s.loading = None; s.types = Counter()

    def host(s, ip, ts):
        h = s.hosts.get(ip)
        if not h: h = s.hosts[ip] = dict(ip=ip, macs=set(), pk=0, bo=0, bi=0, first=ts, last=ts, served=Counter(), peers=set())
        h['last'] = ts; return h

    def ingest(s, ts, lt, raw):
        if len(s.raw) >= MAXP: s.dropped += 1; return
        d = dissect(raw, lt)
        with s.lock:
            n = len(s.raw)
            if n >= MAXP: s.dropped += 1; return
            s.raw.append((lt, raw)); ln = len(raw)
            rec = dict(n=n, ts=ts, len=ln, proto=d['label'], src=d['src'], dst=d['dst'], sp=d['sp'], dp=d['dp'], info=d['info'][:200], fid=None)
            s.pk.append(rec); b = s.tl[int(ts)]; b[0] += 1; b[1] += ln; s.types[d['label']] += 1
            if d.get('wlan'): s._wlan(ts, d)
            if d.get('tp') in ('TCP', 'UDP', 'ICMP', 'ICMPv6', 'ARP') and d['src']: s._flow(ts, ln, d, rec)
            s.rev += 1

    def _flow(s, ts, ln, d, rec):
        tp, a, b = d['tp'], (d['src'], d['sp']), (d['dst'], d['dp']); key = (tp,) + (a + b if a <= b else b + a)
        f = s.flows.get(key)
        if not f:
            fg = d.get('flags', 0)
            if tp == 'TCP' and fg & 2 and not fg & 16: cl = a
            elif tp == 'TCP' and fg & 2 and fg & 16: cl = b
            elif a[1] and b[1] and a[1] != b[1] and tp in ('TCP', 'UDP'): cl = a if a[1] > b[1] else b
            else: cl = a
            sv = b if cl == a else a
            f = s.flows[key] = dict(id=len(s.fl), proto=tp, cli=cl[0], cp=cl[1], srv=sv[0], sp=sv[1], first=ts, last=ts, pk=0, by=0, pkc=0, byc=0,
                                    syn=0, synack=0, fin=0, rst=0, l7={}, app=None, ts=[], svc=f'{tp}:{sv[1]}' if sv[1] else tp)
            s.fl.append(f)
        isc = (a == (f['cli'], f['cp'])); fg = d.get('flags', 0)
        f['last'] = ts; f['pk'] += 1; f['by'] += ln
        if isc: f['pkc'] += 1; f['byc'] += ln
        if isc and len(f['ts']) < 400: f['ts'].append(ts)
        if tp == 'TCP':
            if fg & 2 and not fg & 16: f['syn'] += 1
            if fg & 2 and fg & 16: f['synack'] += 1
            if fg & 1: f['fin'] += 1
            if fg & 4: f['rst'] += 1
        if d.get('app') and not f['app']: f['app'] = d['app']
        q = d.get('dns')
        if q:
            if q['q'] and 'dns' not in f['l7']: f['l7']['dns'] = q['q']
            if q['qr']:
                if q['rc'] == 3: s.nx[d['dst']] += 1
                for ip in q['ans']: s.names.setdefault(ip, q['q'])
        if d.get('sni'): f['l7']['sni'] = d['sni']; s.names.setdefault(f['srv'], d['sni'])
        if d.get('http'): f['l7'].setdefault('http', d['http']['line']); d['http']['host'] and f['l7'].setdefault('host', d['http']['host'])
        rec['fid'] = f['id']
        for ip, out in ((d['src'], True), (d['dst'], False)):
            h = s.host(ip, ts); h['pk'] += 1
            if out: h['bo'] += ln; h['peers'].add(d['dst'])
            else: h['bi'] += ln; h['peers'].add(d['src'])
            if d.get('smac') and out and is_priv(ip): h['macs'].add(d['smac'])
        if tp in ('TCP', 'UDP') and not isc and not (fg & 4) and not f.get('rep'):
            f['rep'] = 1; s.hosts[f['srv']]['served'][f['sp']] += 1

    def _wlan(s, ts, d):
        w = d['wlan']; bs = w.get('bssid'); rs = w.get('rssi')
        def ap(m):
            return s.aps.setdefault(m, dict(bssid=m, ssid='', ch=None, enc='?', beacons=0, pk=0, first=ts, last=ts, rssi=None, clients=set()))
        def st(m):
            if not m or int(m[:2], 16) & 1: return None
            return s.sta.setdefault(m, dict(mac=m, bssid=None, probes=set(), pk=0, first=ts, last=ts, rssi=None))
        if w['t'] == 0 and w.get('name') in ('Beacon', 'ProbeResp') and w['a2']:
            a = ap(w['a2']); a['last'] = ts; a['pk'] += 1
            if w.get('name') == 'Beacon': a['beacons'] += 1
            if w.get('ssid'): a['ssid'] = w['ssid']
            if w.get('ch'): a['ch'] = w['ch']
            a['enc'] = w.get('enc', a['enc'])
            if rs is not None: a['rssi'] = rs
        elif w['t'] == 0 and w.get('name') == 'ProbeReq':
            x = st(w['a2'])
            if x:
                x['pk'] += 1; x['last'] = ts
                if w.get('ssid'): x['probes'].add(w['ssid'])
                if rs is not None: x['rssi'] = rs
        elif w['t'] == 0 and w.get('name') in ('Deauth', 'Disassoc'):
            k = (w['a2'], w['a1'], w['name']); e = s.deauth.setdefault(k, dict(src=w['a2'], dst=w['a1'], kind=w['name'], n=0, first=ts, last=ts, reasons=Counter()))
            e['n'] += 1; e['last'] = ts; e['reasons'][w.get('reason')] += 1
        elif w['t'] == 0 and w.get('name') in ('Auth', 'AssocReq', 'ReassocReq'):
            x = st(w['a2'])
            if x and bs: x['bssid'] = bs; x['pk'] += 1; x['last'] = ts; ap(bs)['clients'].add(w['a2'])
        if w['t'] == 2 and w.get('bssid') and w.get('sta'):
            x = st(w['sta']); a = ap(w['bssid']); a['clients'].add(w['sta']); a['last'] = ts
            if x:
                x['bssid'] = w['bssid']; x['pk'] += 1; x['last'] = ts
                if rs is not None and w['sta'] == w['a2']: x['rssi'] = rs
            if w.get('eapol'):
                e = s.hs.setdefault((w['bssid'], w['sta']), dict(bssid=w['bssid'], sta=w['sta'], msgs=set(), first=ts, last=ts)); e['msgs'].add(w['eapol']); e['last'] = ts

S = Store()

# ---------------------------------------------------------------- derived views
def flow_state(f):
    if f['proto'] == 'TCP':
        if f['rst']: return 'RESET'
        if f['syn'] and f['synack'] and f['fin']: return 'CLOSED'
        if f['syn'] and f['synack']: return 'ESTABLISHED'
        if f['syn'] and not f['synack']: return 'NO-REPLY'
        return 'MIDSTREAM'
    return 'REPLIED' if f['pk'] > f['pkc'] and f['pkc'] else ('UNANSWERED' if f['pkc'] else 'ONE-WAY')

def fjson(f):
    return dict(id=f['id'], proto=f['proto'], cli=f['cli'], cp=f['cp'], srv=f['srv'], sp=f['sp'], svc=f['svc'], app=f['app'], first=f['first'], last=f['last'],
                pk=f['pk'], by=f['by'], pkc=f['pkc'], byc=f['byc'], state=flow_state(f), l7=f['l7'])

def label(ip): return S.names.get(ip)

def graph(kind='ip', q='', lim=700):
    with S.lock:
        ed = {}
        for f in S.fl:
            if q and q.lower() not in f"{f['cli']} {f['srv']} {f['svc']} {f['app']} {label(f['srv'])}".lower(): continue
            a, b = f['cli'], f['srv']; k = (a, b) if a <= b else (b, a); e = ed.get(k)
            if not e: e = ed[k] = dict(a=a, b=b, pk=0, by=0, pkab=0, pkba=0, svc=Counter(), fl=0, st=Counter())
            e['pk'] += f['pk']; e['by'] += f['by']; e['fl'] += 1; e['svc'][f['svc'] + (f'({f["app"]})' if f['app'] and f['app'] not in f['svc'] else '')] += f['pk']; e['st'][flow_state(f)] += 1
            if (f['cli'], f['srv']) == (e['a'], e['b']): e['pkab'] += f['pkc']; e['pkba'] += f['pk'] - f['pkc']
            else: e['pkba'] += f['pkc']; e['pkab'] += f['pk'] - f['pkc']
        top = sorted(ed.values(), key=lambda e: -e['by'])[:max(20, min(lim, 700))]; nodes = {}
        for e in top:
            for ip in (e['a'], e['b']):
                if ip not in nodes:
                    h = S.hosts[ip]; nodes[ip] = dict(id=ip, kind='host', label=label(ip), local=is_priv(ip), multi=is_multi(ip), pk=h['pk'], by=h['bo'] + h['bi'],
                                                      out=h['bo'], inn=h['bi'], served=sorted(h['served'], key=lambda p: -h['served'][p])[:5], mac=sorted(h['macs'])[:2], peers=len(h['peers']))
        ges = [dict(a=e['a'], b=e['b'], pk=e['pk'], by=e['by'], pkab=e['pkab'], pkba=e['pkba'], fl=e['fl'], svc=[[k, v] for k, v in e['svc'].most_common(4)], st=dict(e['st'])) for e in top]
        if kind == 'wlan' or not q:
            for m, a in S.aps.items():
                if not (a['beacons'] or a['clients']): continue
                nodes['ap:' + m] = dict(id='ap:' + m, kind='ap', label=a['ssid'] or '(hidden)', mac=[m], pk=a['pk'], by=0, out=0, inn=0, local=True, multi=False, enc=a['enc'], ch=a['ch'], served=[], peers=len(a['clients']))
                for c in a['clients']:
                    if c in S.sta:
                        x = S.sta[c]; nodes['sta:' + c] = dict(id='sta:' + c, kind='sta', label=None, mac=[c], pk=x['pk'], by=0, out=0, inn=0, local=True, multi=False, served=[], peers=0)
                        ges.append(dict(a='sta:' + c, b='ap:' + m, pk=x['pk'], by=0, pkab=x['pk'], pkba=0, fl=1, svc=[['WLAN', x['pk']]], st={}))
        if kind == 'wlan':
            nodes = {k: v for k, v in nodes.items() if v['kind'] != 'host'}; ges = [e for e in ges if e['a'] in nodes and e['b'] in nodes]
        return dict(nodes=list(nodes.values()), edges=ges, rev=S.rev)

def match(r, toks):
    for t in toks:
        m = re.match(r'(ip|src|dst|port|flow|proto)(==|=|:)(.+)', t, re.I)
        if m:
            k, v = m.group(1).lower(), m.group(3).lower()
            if k == 'ip' and v not in (r['src'].lower(), r['dst'].lower()): return False
            if k == 'src' and r['src'].lower() != v: return False
            if k == 'dst' and r['dst'].lower() != v: return False
            if k == 'port' and v not in (str(r['sp']), str(r['dp'])): return False
            if k == 'flow' and str(r['fid']) != v: return False
            if k == 'proto' and r['proto'].lower() != v: return False
        elif t.startswith('!'):
            if t[1:].lower() in (r['proto'] + ' ' + r['info']).lower(): return False
        elif t.lower() not in f"{r['proto']} {r['src']} {r['dst']} {r['info']}".lower(): return False
    return True

def packets(q='', off=0, lim=400):
    with S.lock:
        toks = q.split()
        if not toks: tot = len(S.pk); off = max(0, tot - lim) if off < 0 else off; rows = S.pk[off:off+lim]
        else:
            m = [r for r in S.pk if match(r, toks)]; tot = len(m); off = max(0, tot - lim) if off < 0 else off; rows = m[off:off+lim]
        t0 = S.pk[0]['ts'] if S.pk else 0
        return dict(total=tot, off=off, t0=t0, rows=rows)

def packet_detail(n):
    with S.lock:
        if not (0 <= n < len(S.raw)): return None
        lt, raw = S.raw[n]; rec = S.pk[n]
    d = dissect(raw, lt, True)
    layers = [dict(name='Frame', fields=[('number', n), ('captured_bytes', len(raw)), ('link_type', lt), ('epoch', f"{rec['ts']:.6f}")])] + [dict(name=a, fields=b) for a, b in d['layers']]
    if d.get('sni'): layers.append(dict(name='TLS ClientHello', fields=[('server_name', d['sni'])]))
    if d.get('http'): layers.append(dict(name='HTTP request', fields=[('request', d['http']['line']), ('host', d['http']['host'])]))
    hx = [dict(o=i, h=' '.join('%02x' % c for c in raw[i:i+16]), a=''.join(chr(c) if 32 <= c < 127 else '.' for c in raw[i:i+16])) for i in range(0, len(raw), 16)]
    return dict(rec=rec, layers=layers, hex=hx, flow=fjson(S.fl[rec['fid']]) if rec['fid'] is not None else None)

def timeline():
    with S.lock:
        if not S.tl: return dict(buckets=[], events=[])
        t0, t1 = min(S.tl), max(S.tl); step = max(1, (t1 - t0) // 240 + 1); bk = defaultdict(lambda: [0, 0])
        for t, v in S.tl.items(): k = (t - t0) // step; bk[k][0] += v[0]; bk[k][1] += v[1]
        return dict(t0=t0, step=step, buckets=[[t0 + k * step] + bk[k] for k in range(int((t1 - t0) // step) + 1) if k in bk or True])

def story(lim=1500):
    with S.lock:
        ev = []
        first = {}
        for f in S.fl:
            for ip in (f['cli'], f['srv']): first.setdefault(ip, f['first'])
        for ip, t in first.items(): ev.append(dict(t=t, k='HOST', msg=f"{ip}{' (' + label(ip) + ')' if label(ip) else ''} first observed"))
        for f in S.fl:
            ex = f['l7'].get('sni') or f['l7'].get('host') or f['l7'].get('dns') or ''
            ev.append(dict(t=f['first'], k='OPEN', fid=f['id'], msg=f"{f['cli']}:{f['cp']} ──{f['svc']}──> {f['srv']}  {ex}"))
            st = flow_state(f)
            if st in ('RESET', 'NO-REPLY', 'CLOSED') and f['last'] > f['first']: ev.append(dict(t=f['last'], k=st, fid=f['id'], msg=f"{f['cli']} ──{f['svc']}──> {f['srv']} {st} after {f['pk']} pkts / {f['by']} B"))
            elif st == 'NO-REPLY': ev.append(dict(t=f['first'], k=st, fid=f['id'], msg=f"{f['srv']}:{f['sp']} never answered {f['cli']}"))
        for a in S.aps.values(): ev.append(dict(t=a['first'], k='AP', msg=f"AP {a['bssid']} \"{a['ssid']}\" ch{a['ch']} {a['enc']}"))
        for e in S.deauth.values(): ev.append(dict(t=e['first'], k='DEAUTH', msg=f"{e['kind']} {e['src']} → {e['dst']} x{e['n']} observed"))
        ev.sort(key=lambda e: e['t']); return dict(events=ev[:lim], total=len(ev))

def analysis():
    with S.lock:
        tot = len(S.pk); by = sum(r['len'] for r in S.pk); F = []
        pr = Counter(); prb = Counter()
        for r in S.pk: pr[r['proto']] += 1; prb[r['proto']] += r['len']
        talk = sorted(S.hosts.values(), key=lambda h: -(h['bo'] + h['bi']))[:12]
        sizes = Counter(min(r['len'] // 100, 15) for r in S.pk)
        # findings: indicators derived strictly from observed packets
        ct = defaultdict(list)
        for f in S.fl:
            if f['proto'] in ('TCP', 'UDP') and f['sp'] in CLEARTEXT and f['pk'] > 2 and f['pk'] > f['pkc'] and f['app'] in (None, CLEARTEXT[f['sp']], 'HTTP'): ct[(f['srv'], f['sp'])].append(f)
        for (srv, sp), fs in ct.items():
            cl = sorted({f['cli'] for f in fs}); F.append(dict(sev='MED', t=f'Cleartext {CLEARTEXT[sp]} on {srv}:{sp}', d=f"{len(fs)} flows from {len(cl)} client(s) ({', '.join(cl[:4])}{'…' if len(cl) > 4 else ''}). Payload crosses the wire unencrypted.", fid=fs[0]['id']))
        srcs = defaultdict(list)
        for f in S.fl:
            if f['proto'] == 'TCP' and f['syn']: srcs[f['cli']].append(f)
        for ip, fs in srcs.items():
            tg = {(f['srv'], f['sp']) for f in fs}; na = sum(1 for f in fs if not f['synack'])
            if len(tg) >= 20 and na / len(fs) > .7: F.append(dict(sev='HIGH', t='Wide SYN fan-out with few replies', d=f"{ip} sent SYNs to {len(tg)} distinct host:port targets; {na}/{len(fs)} flows got no SYN-ACK. Pattern consistent with port/host scanning.", host=ip))
        for f in S.fl:
            if len(f['ts']) >= 8:
                iv = [b - a for a, b in zip(f['ts'], f['ts'][1:]) if b > a]
                if len(iv) >= 7:
                    m = statistics.mean(iv); sd = statistics.pstdev(iv)
                    if m >= 0.5 and sd / m < 0.08: F.append(dict(sev='MED', t='Periodic connection timing', d=f"{f['cli']} → {f['srv']} {f['svc']}: {len(iv)+1} client packets at ~{m:.1f}s intervals (jitter {sd/m*100:.1f}%). Regular timing; may be a heartbeat, poller or beacon.", fid=f['id']))
            if f['proto'] == 'TCP' and f['rst'] and f['pk'] >= 6 and f['rst'] / f['pk'] > .15: F.append(dict(sev='LOW', t='High reset ratio', d=f"{f['cli']} → {f['srv']}:{f['sp']} {f['rst']} RST in {f['pk']} pkts.", fid=f['id']))
        for ip, n in S.nx.items():
            if n >= 10: F.append(dict(sev='LOW', t='Many NXDOMAIN answers', d=f"{ip} received {n} NXDOMAIN responses.", host=ip))
        for e in S.deauth.values():
            if e['n'] >= 10: F.append(dict(sev='HIGH', t=f"{e['kind']} burst observed", d=f"{e['n']} {e['kind']} frames {e['src']} → {e['dst']} over {e['last']-e['first']:.1f}s. Management frames are unauthenticated; investigate the source.", host=e['src']))
        for a in S.aps.values():
            if a['beacons'] and a['enc'] in ('OPEN', 'WEP', 'WPA'): F.append(dict(sev='MED' if a['enc'] == 'OPEN' else 'HIGH', t=f"Weak WLAN security: {a['enc']}", d=f"AP {a['bssid']} \"{a['ssid']}\" advertises {a['enc']}.", host=a['bssid']))
        order = {'HIGH': 0, 'MED': 1, 'LOW': 2}; F.sort(key=lambda x: order[x['sev']])
        return dict(total=tot, bytes=by, flows=len(S.fl), hosts=len(S.hosts),
                    proto=[[k, v, prb[k]] for k, v in pr.most_common(12)],
                    talkers=[dict(ip=h['ip'], label=label(h['ip']), out=h['bo'], inn=h['bi'], peers=len(h['peers']), pk=h['pk']) for h in talk],
                    sizes=[[i * 100, sizes[i]] for i in range(16)], findings=F[:200],
                    dur=(S.pk[-1]['ts'] - S.pk[0]['ts']) if tot > 1 else 0)

def wireless_view():
    with S.lock:
        aps = [dict(bssid=a['bssid'], ssid=a['ssid'], ch=a['ch'], enc=a['enc'], beacons=a['beacons'], pk=a['pk'], rssi=a['rssi'], clients=len(a['clients']), last=a['last']) for a in S.aps.values()]
        sta = [dict(mac=x['mac'], bssid=x['bssid'], probes=sorted(x['probes'])[:6], pk=x['pk'], rssi=x['rssi'], last=x['last']) for x in S.sta.values()]
        hs = [dict(bssid=h['bssid'], sta=h['sta'], msgs=sorted(h['msgs']), complete=h['msgs'] >= {1, 2, 3} or h['msgs'] >= {2, 3, 4} or h['msgs'] == {1, 2, 3, 4}) for h in S.hs.values()]
        da = [dict(src=e['src'], dst=e['dst'], kind=e['kind'], n=e['n'], dur=e['last'] - e['first'], reasons=dict((str(k), v) for k, v in e['reasons'].items())) for e in S.deauth.values()]
        chs = Counter(a['ch'] for a in S.aps.values() if a['ch'] and a['beacons'])
        return dict(frames=sum(1 for r in S.pk if r['proto'] in ('WLAN', 'EAPOL')) or len(S.aps) + len(S.sta) + len(S.hs), aps=sorted(aps, key=lambda a: -(a['beacons'])), stations=sta, handshakes=hs, deauth=da, channels=sorted(chs.items(), key=lambda x: x[0]))

def state():
    with S.lock:
        w = sum(1 for _ in S.aps)
        return dict(rev=S.rev, packets=len(S.pk), flows=len(S.fl), hosts=len(S.hosts), aps=w, src=S.src, err=S.err, dropped=S.dropped, loading=S.loading,
                    live=CAP.live, iface=CAP.iface, kdrop=CAP.kdrop, t0=S.pk[0]['ts'] if S.pk else None, t1=S.pk[-1]['ts'] if S.pk else None,
                    now=time.time(), root=(os.geteuid() == 0) if hasattr(os, 'geteuid') else False, termux=TERMUX, maxp=MAXP)

# ---------------------------------------------------------------- live capture
def ifaces():
    out, base = [], '/sys/class/net'
    try: names = sorted(os.listdir(base))
    except OSError: names = []
    if not names:   # Android often hides /sys/class/net
        try: names = sorted(n for _, n in socket.if_nameindex())
        except (OSError, AttributeError): names = []
    def rd(n, p, dflt=''):
        try: return open(f'{base}/{n}/{p}').read().strip()
        except Exception: return dflt
    for n in names:
        ty = rd(n, 'type', '0'); wl = os.path.isdir(f'{base}/{n}/wireless') or os.path.isdir(f'{base}/{n}/phy80211') or n.startswith('wlan')
        kind = 'monitor' if ty == '803' else 'wireless' if wl else 'loopback' if n == 'lo' else 'ethernet' if ty == '1' or n.startswith('eth') else 'cellular' if re.match(r'(rmnet|ccmni|v4-rmnet)', n) else 'other'
        out.append(dict(name=n, type=int(ty) if ty.isdigit() else 0, kind=kind, state=rd(n, 'operstate'), mac=rd(n, 'address')))
    out.append(dict(name=f'pcapdroid:{PCAPDROID_PORT}', type=-1, kind='stream', state='listen', mac=''))   # no-root live source
    return out

CAP_DIRS = ['~', '~/storage/downloads', '~/storage/downloads/PCAPdroid', '~/storage/shared/Download', '~/storage/shared/Download/PCAPdroid', '~/storage/shared/Documents',
            '/sdcard/Download', '/sdcard/Download/PCAPdroid', '/storage/emulated/0/Download', '/storage/emulated/0/Download/PCAPdroid', '.']
def find_captures(lim=12):
    seen, out = set(), []
    for d in CAP_DIRS:
        try: names = os.listdir(os.path.expanduser(d))
        except OSError: continue
        for n in names:
            if not n.lower().endswith(('.pcap', '.pcapng', '.cap')): continue
            try:
                p = os.path.realpath(os.path.join(os.path.expanduser(d), n)); st = os.stat(p)
            except OSError: continue
            if p in seen or not stat.S_ISREG(st.st_mode): continue
            seen.add(p); out.append(dict(path=p, name=n, size=st.st_size, mtime=st.st_mtime))
    return sorted(out, key=lambda x: -x['mtime'])[:lim]

class Capture:
    live = False; iface = None; sock = None; th = None; kdrop = 0; krecv = 0
    def stats(s, sk):
        try: r, d = struct.unpack('II', sk.getsockopt(263, 6, 8)); s.krecv += r; s.kdrop += d
        except Exception: pass
    def start(s, iface):
        if s.live: raise RuntimeError('capture already running')
        if iface.startswith('pcapdroid'): return s.start_stream(int(iface.split(':')[1]) if ':' in iface else PCAPDROID_PORT)
        info = {i['name']: i for i in ifaces()}
        if iface not in info: raise RuntimeError(f'unknown interface {iface}')
        ty = info[iface]['type']; lt = {1: 1, 772: 1, 803: 127, 801: 105, 65534: 101, 519: 101}.get(ty, 1)
        try: sk = socket.socket(socket.AF_PACKET, socket.SOCK_RAW, socket.ntohs(3)); sk.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 64 << 20); sk.bind((iface, 0)); sk.settimeout(0.4)
        except (PermissionError, AttributeError, OSError) as e: raise RuntimeError(f'cannot open raw socket on {iface}: {e}. Raw capture needs root (Termux: install tsu and run it from a root shell). No root? Pick the pcapdroid stream source or load a PCAP.')
        S.reset(); S.src = f'LIVE {iface}'; s.sock, s.iface, s.live, s.kdrop, s.krecv = sk, iface, True, 0, 0
        s.th = threading.Thread(target=s.loop, args=(sk, iface, lt), daemon=True); s.th.start()
    def start_stream(s, port):
        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM); srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try: srv.bind(('127.0.0.1', port)); srv.listen(1); srv.settimeout(0.5)
        except OSError as e: srv.close(); raise RuntimeError(f'cannot listen on 127.0.0.1:{port}: {e}')
        S.reset(); S.src = f'LIVE pcapdroid:{port}'; s.sock, s.iface, s.live, s.kdrop, s.krecv = srv, f'pcapdroid:{port}', True, 0, 0
        s.th = threading.Thread(target=s.sloop, args=(srv,), daemon=True); s.th.start()
    def sloop(s, srv):
        while s.live:
            try: c, _ = srv.accept()
            except socket.timeout: continue
            except OSError: break
            c.settimeout(0.5); sp = StreamParser(S.ingest)
            try:
                while s.live:
                    try: d = c.recv(65536)
                    except socket.timeout: continue
                    if not d: break
                    sp.feed(d)
            except (OSError, ValueError) as e: S.err = f'stream: {e}'
            finally: c.close()
    def loop(s, sk, iface, lt):
        while s.live:
            try: data, addr = sk.recvfrom(65535)
            except socket.timeout: s.stats(sk); continue
            except OSError: break
            if iface == 'lo' and addr[2] == 4: continue  # loopback delivers each frame twice
            S.ingest(time.time(), lt, data)
    def stop(s):
        s.live = False
        if s.sock:
            s.stats(s.sock)
            try: s.sock.shutdown(socket.SHUT_RDWR)   # wakes a blocked accept()
            except OSError: pass
            s.sock.close(); s.sock = None
        if s.th and s.th is not threading.current_thread(): s.th.join(1.5)
CAP = Capture()

def load_file(path, name=None, cleanup=False):
    def run():
        try:
            S.reset(); S.src = name or os.path.basename(path); S.loading = dict(done=0, total=1)
            def prog(o, n): S.loading = dict(done=o, total=n)
            read_capture(path, S.ingest, prog)
            if not S.pk: S.err = 'Capture contained no readable packets.'
        except Exception as e: S.err = f'{type(e).__name__}: {e}'
        finally:
            S.loading = None; S.rev += 1
            if cleanup:
                try: os.remove(path)
                except OSError: pass
    CAP.stop(); t = threading.Thread(target=run, daemon=True); t.start(); return t

def export_pcap():
    with S.lock:
        if not S.raw: return None
        lt0 = S.raw[0][0]; out = [struct.pack('<IHHiIII', 0xa1b2c3d4, 2, 4, 0, 0, 65535, lt0)]
        for (lt, raw), r in zip(S.raw, S.pk):
            if lt != lt0: continue
            ts = r['ts']; out.append(struct.pack('<IIII', int(ts), int((ts % 1) * 1e6), len(raw), len(raw)) + raw)
        return b''.join(out)

# ---------------------------------------------------------------- authorization scope (active testing is gated)
class Scope:
    def __init__(s): s.nets, s.audit, s.probes = [], [], 0
    def log(s, what): s.audit.append(dict(t=time.time(), msg=what))
    def authorize(s, target, phrase):
        if phrase.strip().upper() != f'I AM AUTHORIZED TO TEST {target}'.upper(): raise ValueError(f'confirmation must read exactly: I AM AUTHORIZED TO TEST {target}')
        n = ipaddress.ip_network(target, strict=False)
        if n.is_multicast or n.is_unspecified or n.prefixlen < (24 if n.version == 4 else 120): raise ValueError('target must be a specific host or a network no larger than /24')
        s.nets.append(n); s.log(f'scope + {n} (operator attested authorization)'); return str(n)
    def allowed(s, ip):
        a = ipaddress.ip_address(ip); return any(a in n for n in s.nets)
    def probe(s, ip, port):
        if not s.allowed(ip): raise PermissionError(f'{ip} is not in the authorized scope. Add it in SETTINGS > AUTHORIZATION first.')
        if s.probes >= 20: raise PermissionError('probe limit (20 per session) reached')
        if not 0 < port < 65536: raise ValueError('bad port')
        s.probes += 1; t = time.time()
        try:
            c = socket.create_connection((ip, port), timeout=2); c.close(); r = 'OPEN'
        except ConnectionRefusedError: r = 'CLOSED'
        except OSError: r = 'FILTERED/TIMEOUT'
        s.log(f'tcp-connect {ip}:{port} -> {r} ({(time.time()-t)*1000:.0f} ms)'); return r
SC = Scope()

# ---------------------------------------------------------------- console
def console(line):
    p = line.strip().split(); 
    if not p: return ''
    c, a = p[0].lower(), p[1:]
    try:
        if c == 'help': return ('stats | hosts [n] | flows [n] | top | dns | find <text> | show <pkt#> | ifaces | files | load <path>\n'
                                'capture start <iface> | capture stop | clear\n'
                                'scope list | scope add <ip/cidr> | authorize <ip/cidr> I AM AUTHORIZED TO TEST <ip/cidr>\n'
                                'probe <ip> <port>   (TCP connect, authorized scope only)   | audit')
        if c == 'stats': x = analysis(); return f"packets={x['total']} bytes={x['bytes']} flows={x['flows']} hosts={x['hosts']} duration={x['dur']:.2f}s\n" + '\n'.join(f'  {k:10} {v:8} pkts {b:10} B' for k, v, b in x['proto'])
        if c == 'hosts':
            n = int(a[0]) if a else 15
            return '\n'.join(f"{h['ip']:40} out={h['bo']:>9} in={h['bi']:>9} peers={len(h['peers'])} {label(h['ip']) or ''}" for h in sorted(S.hosts.values(), key=lambda h: -(h['bo'] + h['bi']))[:n]) or '[ NO TRAFFIC DETECTED ]'
        if c == 'flows':
            n = int(a[0]) if a else 15
            return '\n'.join(f"#{f['id']:<5} {f['cli']}:{f['cp']} ──{f['svc']}──> {f['srv']}  {f['pk']}pk {f['by']}B {flow_state(f)}" for f in sorted(S.fl, key=lambda f: -f['by'])[:n]) or '[ NO TRAFFIC DETECTED ]'
        if c == 'top': return '\n'.join(f"{t['ip']:40} {t['out']+t['inn']:>10} B" for t in analysis()['talkers'])
        if c == 'dns': return '\n'.join(f"{ip:40} {n}" for ip, n in list(S.names.items())[:50]) or 'no DNS/SNI names observed'
        if c == 'find': r = packets(' '.join(a), 0, 25); return f"{r['total']} matches\n" + '\n'.join(f"#{x['n']} {x['src']} → {x['dst']} {x['proto']} {x['info'][:90]}" for x in r['rows'])
        if c == 'show':
            d = packet_detail(int(a[0])); 
            if not d: return 'no such packet'
            return '\n'.join(f"[{l['name']}]\n" + '\n'.join(f'  {k}: {v}' for k, v in l['fields']) for l in d['layers'])
        if c == 'ifaces': return '\n'.join(f"{i['name']:12} {i['kind']:9} {i['state']:8} {i['mac']}" for i in ifaces())
        if c == 'files': return '\n'.join(f"{f['path']}  {f['size']//1024} KB" for f in find_captures(30)) or 'no .pcap/.pcapng files found (Termux: run termux-setup-storage)'
        if c == 'load': load_file(os.path.expanduser(' '.join(a))).join(); return state()['err'] or f"loaded {S.src}: {len(S.pk)} packets, {len(S.fl)} flows"
        if c == 'capture':
            if a and a[0] == 'start': CAP.start(a[1]); return f'capturing on {a[1]}'
            CAP.stop(); return 'capture stopped'
        if c == 'clear': CAP.stop(); S.reset(); return 'cleared'
        if c == 'scope':
            if a and a[0] == 'add': return f'Type exactly:\n  authorize {a[1]} I AM AUTHORIZED TO TEST {a[1]}'
            return '\n'.join(map(str, SC.nets)) or 'scope empty: active operations are locked'
        if c == 'authorize': return 'scope + ' + SC.authorize(a[0], ' '.join(a[1:]))
        if c == 'probe': return f'{a[0]}:{a[1]} {SC.probe(a[0], int(a[1]))}'
        if c == 'audit': return '\n'.join(time.strftime('%H:%M:%S', time.gmtime(x['t'])) + ' ' + x['msg'] for x in SC.audit) or 'audit log empty'
        return f'unknown command: {c}  (try help)'
    except (IndexError, ValueError, RuntimeError, PermissionError) as e: return f'error: {e}'

# ---------------------------------------------------------------- http
class H(BaseHTTPRequestHandler):
    def log_message(s, *a): pass
    def send(s, body, ct='application/json', code=200, extra=None):
        if not isinstance(body, (bytes, bytearray)): body = json.dumps(body, default=lambda o: sorted(o) if isinstance(o, set) else str(o)).encode()
        s.send_response(code); s.send_header('Content-Type', ct); s.send_header('Content-Length', str(len(body))); s.send_header('Cache-Control', 'no-store')
        for k, v in (extra or {}).items(): s.send_header(k, v)
        s.end_headers(); s.wfile.write(body)
    def do_GET(s):
        u = urlparse(s.path); q = {k: v[0] for k, v in parse_qs(u.query).items()}; p = u.path
        try:
            if p in ('/', '/index.html'): return s.send(open(f'{HERE}/static/index.html', 'rb').read(), 'text/html; charset=utf-8')
            if p == '/manifest.webmanifest': return s.send(open(f'{HERE}/static/manifest.webmanifest', 'rb').read(), 'application/manifest+json')
            if p.startswith('/static/') and '..' not in p:
                fp = f'{HERE}{p}'
                if not os.path.isfile(fp): return s.send({'error': 'not found'}, code=404)
                return s.send(open(fp, 'rb').read(), mimetypes.guess_type(fp)[0] or 'application/octet-stream')
            if p == '/api/state': return s.send(state())
            if p == '/api/graph': return s.send(graph(q.get('kind', 'ip'), q.get('q', ''), int(q.get('lim', 700))))
            if p == '/api/flows': return s.send(dict(flows=[fjson(f) for f in S.fl[-20000:]]))
            if p == '/api/packets': return s.send(packets(q.get('q', ''), int(q.get('off', -1)), int(q.get('lim', 400))))
            if p == '/api/packet': return s.send(packet_detail(int(q['n'])) or {})
            if p == '/api/timeline': return s.send(timeline())
            if p == '/api/story': return s.send(story())
            if p == '/api/analysis': return s.send(analysis())
            if p == '/api/wireless': return s.send(wireless_view())
            if p == '/api/ifaces': return s.send(ifaces())
            if p == '/api/files': return s.send(find_captures())
            if p == '/api/scope': return s.send(dict(nets=[str(n) for n in SC.nets], audit=SC.audit))
            if p == '/api/export':
                b = export_pcap(); return s.send(b or b'', 'application/vnd.tcpdump.pcap', 200 if b else 404, {'Content-Disposition': 'attachment; filename=atlasflow.pcap'})
            s.send({'error': 'not found'}, code=404)
        except Exception as e: s.send({'error': str(e)}, code=500)
    def do_POST(s):
        u = urlparse(s.path); q = {k: v[0] for k, v in parse_qs(u.query).items()}; n = int(s.headers.get('Content-Length', 0)); body = s.rfile.read(n)
        try:
            if u.path == '/api/load':
                fd, tmp = tempfile.mkstemp(prefix='atlasflow_', suffix='.cap')
                with os.fdopen(fd, 'wb') as fh: fh.write(body)
                load_file(tmp, q.get('name', 'upload'), cleanup=True); return s.send(dict(ok=True))
            j = json.loads(body or b'{}')
            if u.path == '/api/loadpath':
                pth = os.path.expanduser(j.get('path', ''))
                if not os.path.isfile(pth): return s.send(dict(ok=False, error='file not found'), code=400)
                load_file(pth); return s.send(dict(ok=True))
            if u.path == '/api/capture':
                try:
                    if j.get('action') == 'start': CAP.start(j['iface'])
                    else: CAP.stop()
                    return s.send(dict(ok=True))
                except RuntimeError as e: return s.send(dict(ok=False, error=str(e)), code=400)
            if u.path == '/api/clear': CAP.stop(); S.reset(); return s.send(dict(ok=True))
            if u.path == '/api/console': return s.send(dict(out=console(j.get('cmd', ''))))
            if u.path == '/api/scope':
                try: return s.send(dict(ok=True, net=SC.authorize(j['target'], j['confirm'])))
                except (ValueError, KeyError) as e: return s.send(dict(ok=False, error=str(e)), code=400)
            s.send({'error': 'not found'}, code=404)
        except Exception as e: s.send({'error': str(e)}, code=500)

def open_url(url):
    for cmd in (['termux-open-url', url], ['xdg-open', url], ['am', 'start', '-a', 'android.intent.action.VIEW', '-d', url]):
        if shutil.which(cmd[0]):
            try: subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL); return True
            except OSError: pass
    return False

def main():
    global MAXP
    ap = argparse.ArgumentParser(description='ATLAS FLOW'); ap.add_argument('file', nargs='?'); ap.add_argument('--port', type=int, default=8717)
    ap.add_argument('--capture', metavar='IFACE', help='live capture (root). Use pcapdroid or pcapdroid:PORT for the no-root PCAPdroid stream')
    ap.add_argument('--host', default='127.0.0.1'); ap.add_argument('--open', action='store_true', help='open the UI in the phone browser'); ap.add_argument('--max-packets', type=int)
    a = ap.parse_args()
    if a.max_packets: MAXP = a.max_packets
    if a.file:
        if not os.path.isfile(os.path.expanduser(a.file)): sys.exit(f'atlasflow: no such file: {a.file}')
        load_file(os.path.expanduser(a.file))
    if a.capture:
        try: CAP.start(a.capture)
        except RuntimeError as e: print(f'atlasflow: {e}', file=sys.stderr)
    srv = None
    for port in range(a.port, a.port + 10):
        try: srv = ThreadingHTTPServer((a.host, port), H); break
        except OSError: continue
    if not srv: sys.exit(f'atlasflow: ports {a.port}-{a.port + 9} are busy')
    url = f'http://{"127.0.0.1" if a.host in ("0.0.0.0", "") else a.host}:{port}'
    print(f'ATLAS FLOW  {url}   (Ctrl+C to quit)\n  passive analysis; active testing locked until scope is authorized')
    if not (hasattr(os, 'geteuid') and os.geteuid() == 0): print('  not root: load PCAPs or use the pcapdroid stream source for live traffic')
    if a.open: open_url(url)
    try: srv.serve_forever()
    except KeyboardInterrupt: pass
    finally: CAP.stop(); srv.server_close(); print('\nstopped')

if __name__ == '__main__': main()
