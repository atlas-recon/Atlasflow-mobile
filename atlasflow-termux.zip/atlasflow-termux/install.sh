#!/data/data/com.termux/files/usr/bin/env bash
# ATLAS FLOW - Termux installer.  Usage: bash install.sh [--uninstall]
set -e
PREFIX="${PREFIX:-$HOME/.local}"
DEST="$PREFIX/share/atlasflow"
BIN="$PREFIX/bin/atlasflow"
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [ "$1" = "--uninstall" ]; then rm -rf "$DEST" "$BIN"; echo "removed atlasflow"; exit 0; fi

if ! command -v python3 >/dev/null 2>&1; then
  if command -v pkg >/dev/null 2>&1; then pkg install -y python; else echo "python3 is required"; exit 1; fi
fi
python3 -c 'import sys; sys.exit(sys.version_info < (3, 8))' || { echo "python 3.8+ required"; exit 1; }

mkdir -p "$DEST" "$PREFIX/bin"
rm -rf "$DEST/static"
cp -r "$SRC/atlasflow.py" "$SRC/static" "$DEST/"

cat > "$BIN" <<LAUNCH
#!$(command -v bash)
# atlasflow [pcap] [--capture IFACE|pcapdroid] [--port N] [--no-open]
OPEN=--open; ARGS=()
for a in "\$@"; do [ "\$a" = "--no-open" ] && OPEN= || ARGS+=("\$a"); done
command -v termux-wake-lock >/dev/null 2>&1 && { termux-wake-lock; trap 'termux-wake-unlock' EXIT; }
python3 "$DEST/atlasflow.py" \$OPEN "\${ARGS[@]}"
LAUNCH
chmod +x "$BIN"

# access to Downloads (so captures show up inside the app)
if command -v termux-setup-storage >/dev/null 2>&1 && [ ! -d "$HOME/storage" ]; then termux-setup-storage || true; fi

echo
echo "installed. Run:  atlasflow"
echo "(opens http://127.0.0.1:8717 in your browser - rotate the phone freely)"
