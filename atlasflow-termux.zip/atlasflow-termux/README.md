# ATLAS FLOW - Termux edition

See the flow. Understand the network. Passive network + wireless analysis. Stdlib-only Python 3: the only dependency is `python`.
Same UI as the desktop build, re-flowed for phones: works in portrait and landscape, touch pan / pinch / tap, bottom and side sheets.

## Install

    pkg install -y unzip
    unzip atlasflow-termux.zip && bash atlasflow-termux/install.sh     # (from ~/storage/downloads after termux-setup-storage)

## Run

    atlasflow                       # starts the server and opens the UI in your browser
    atlasflow capture.pcapng        # load a file on start
    atlasflow --no-open             # don't launch the browser
    atlasflow --port 9000

Stop with Ctrl+C. Uninstall: `bash install.sh --uninstall`.
Tip: browser menu > "Add to Home screen" gives a full-screen app. The menu button (☰) has fullscreen and rotation lock.

## Getting traffic

| Source | Root | How |
|---|---|---|
| PCAP / PCAPNG file | no | tap an on-device capture on the start screen (scans Downloads, PCAPdroid folder, home), or ☰ > load pcap |
| PCAPdroid live stream | no | PCAPdroid > Settings > PCAP dump > **TCP exporter**, server `127.0.0.1` port `5123`; start the dump, then in AtlasFlow pick `pcapdroid:5123` and **start capture** (start AtlasFlow's listener first) |
| Raw interface capture | yes | `pkg install tsu`, then `tsu` and `atlasflow --capture wlan0`. 802.11 management frames need a monitor-mode interface |

Inputs: PCAP (us/ns, both endians), PCAPNG, raw IP, Ethernet, Linux SLL, 802.11, 802.11+radiotap.
Nothing is simulated. No traffic shows `[ NO TRAFFIC DETECTED ]`.

## Notes
- Packet cap defaults to 300k on Termux to protect RAM (`--max-packets N` or `ATLASFLOW_MAXP`).
- Binds to 127.0.0.1 only. Passive by design: no injection, deauth, cracking or credential capture. The only active action is a gated single TCP connect probe (authorization attestation required, 20 per session, audit-logged).
- Console commands: `help`, `files`, `load <path>`, `stats`, `hosts`, `flows`, `find`, `show <n>`.
